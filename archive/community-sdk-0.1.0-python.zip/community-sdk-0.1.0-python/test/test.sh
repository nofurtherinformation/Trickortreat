python3 -m pytest test -v --capture=no --cov=communitysdk --cov-report term-missing
